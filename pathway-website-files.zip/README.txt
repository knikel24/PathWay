# PathWay - Instagram Bio & Landing Page

## Deployment Instructions (GitHub Pages)

1. Create a repository on GitHub named `pathway` (set to Public).
2. Upload `index.html` and your logo file `image_af3bc0.jpg` into the main repository folder.
3. Go to **Settings** > **Pages** > Select `main` branch under **Branch** and click **Save**.
4. Your website will be live in 1-2 minutes at: `https://<your-username>.github.io/pathway/`

## Admin Panel Access
- Click the **Admin** button in the top navigation header.
- Default Password: `1234`
- View total visits, Instagram referral clicks, captured waitlist emails, and export to CSV.
